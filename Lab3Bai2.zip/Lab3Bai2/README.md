# Bài tập 2 - Lab 3

Ứng dụng Android gồm hai màn hình, sử dụng Java và giao diện XML.

## Mở và chạy trong Android Studio

1. Chọn **File > Open**, chọn thư mục **Lab3Bai2** và đợi Gradle Sync hoàn tất.
2. Chọn điện thoại hoặc máy ảo Android API 24 trở lên.
3. Nhấn **Run app** (nút tam giác màu xanh).
4. Tại màn hình 1, nhấn **Chuyển sang màn hình 2**.
5. Tại màn hình 2, nhấn **Quay lại màn hình 1**.

Project sử dụng Android Gradle Plugin 9.3.3, Gradle 9.5.0 và compile SDK 37 theo bộ công cụ có sẵn trên máy. Dùng Gradle JDK đi kèm Android Studio. Nếu mở trên máy khác, chọn lại Android SDK trong Android Studio; file local.properties là cấu hình riêng của máy và không nằm trong ZIP nộp bài.

## Các file chính

- `app/src/main/java/com/example/lab3bai2/MainActivity.java`: màn hình 1 và Intent mở màn hình 2.
- `app/src/main/java/com/example/lab3bai2/SecondActivity.java`: màn hình 2 và Intent quay về màn hình 1.
- `app/src/main/res/layout/activity_main.xml`: giao diện màn hình 1.
- `app/src/main/res/layout/activity_second.xml`: giao diện màn hình 2.
- `app/src/main/AndroidManifest.xml`: đăng ký hai Activity và màn hình khởi động.

## Giải thích ngắn

`new Intent(MainActivity.this, SecondActivity.class)` là Intent tường minh: chỉ rõ Activity cần mở. `startActivity(intent)` thực hiện chuyển màn hình.

Chiều ngược lại tạo Intent đến `MainActivity`, thêm `FLAG_ACTIVITY_CLEAR_TOP | FLAG_ACTIVITY_SINGLE_TOP` để quay về Activity đầu tiên đã có trong ngăn xếp. `finish()` kết thúc màn hình thứ hai. Nút Back của hệ thống từ màn hình 2 cũng quay về màn hình 1 theo ngăn xếp Android.

## Kiểm tra thao tác

- Mở app: thấy màn hình 1.
- Bấm nút chuyển: thấy màn hình 2.
- Bấm nút quay lại: thấy màn hình 1.
- Lặp lại nhiều lần: không tạo thêm bản sao màn hình 1.
- Từ màn hình 2 bấm Back hệ thống: trở về màn hình 1.

Bài làm dựa trên yêu cầu đã cung cấp: hai màn hình và Intent chuyển qua lại. Chưa có tài liệu mẫu riêng của Lab 3 để đối chiếu giao diện.
