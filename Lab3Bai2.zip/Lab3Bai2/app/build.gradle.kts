plugins { id("com.android.application") }
android {
    namespace = "com.example.lab3bai2"
    compileSdk { version = release(37) }
    defaultConfig {
        applicationId = "com.example.lab3bai2"
        minSdk = 24
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}
