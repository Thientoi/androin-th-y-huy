package com.example.studentprofilemanager

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studentprofilemanager.databinding.ActivityEditProfileBinding

class EditProfileActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "TAG_LIFECYCLE"
    }

    private lateinit var binding: ActivityEditProfileBinding
    private var originalStudent: Student? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "EditProfileActivity -> onCreate")

        binding = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        originalStudent = getStudentFromIntent(intent, MainActivity.EXTRA_STUDENT)

        val current = originalStudent
        if (current == null) {
            toast("Không nhận được dữ liệu sinh viên.")
            finish()
            return
        }

        // Điền sẵn dữ liệu hiện tại.
        binding.edtName.setText(current.name)
        binding.edtClass.setText(current.className)
        binding.edtGpa.setText(current.gpa.toString())

        binding.btnSave.setOnClickListener {
            saveAndReturn()
        }

        // Không setResult -> Android trả RESULT_CANCELED.
        binding.btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun saveAndReturn() {
        val old = originalStudent ?: return

        val name = binding.edtName.text.toString().trim()
        val className = binding.edtClass.text.toString().trim()
        val gpa = binding.edtGpa.text.toString().trim().toDoubleOrNull()

        if (name.isEmpty()) {
            binding.edtName.error = "Vui lòng nhập họ tên"
            binding.edtName.requestFocus()
            return
        }

        if (className.isEmpty()) {
            binding.edtClass.error = "Vui lòng nhập lớp"
            binding.edtClass.requestFocus()
            return
        }

        if (gpa == null || gpa !in 0.0..4.0) {
            binding.edtGpa.error = "GPA phải nằm trong khoảng 0.0 - 4.0"
            binding.edtGpa.requestFocus()
            return
        }

        val updated = old.copy(
            name = name,
            className = className,
            gpa = gpa
        )

        val resultIntent = Intent().apply {
            putExtra(MainActivity.EXTRA_UPDATED_STUDENT, updated)
        }

        // PHẢI gọi setResult trước finish().
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    private fun getStudentFromIntent(intent: Intent, key: String): Student? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra(key, Student::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra(key) as? Student
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "EditProfileActivity -> onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "EditProfileActivity -> onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "EditProfileActivity -> onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "EditProfileActivity -> onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG, "EditProfileActivity -> onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "EditProfileActivity -> onDestroy")
    }
}
