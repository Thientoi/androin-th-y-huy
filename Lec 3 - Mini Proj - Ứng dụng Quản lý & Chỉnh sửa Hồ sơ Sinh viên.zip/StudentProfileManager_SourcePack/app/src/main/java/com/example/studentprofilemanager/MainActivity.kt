package com.example.studentprofilemanager

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.studentprofilemanager.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "TAG_LIFECYCLE"
        const val EXTRA_STUDENT = "STUDENT"
        const val EXTRA_UPDATED_STUDENT = "UPDATED"
    }

    private lateinit var binding: ActivityMainBinding

    // =========================================================
    // THAY 6 DÒNG DƯỚI ĐÂY BẰNG THÔNG TIN CÁ NHÂN CỦA BẠN.
    // Không để dữ liệu mẫu trước khi quay video/nộp bài.
    // =========================================================
    private var student = Student(
        id = "THAY_MSSV_CUA_BAN",
        name = "THAY_HO_TEN_CUA_BAN",
        className = "THAY_LOP_CUA_BAN",
        email = "THAY_EMAIL_CUA_BAN",
        phone = "0905123456",
        gpa = 3.80
    )

    // 1) Launcher mở EditProfileActivity và nhận dữ liệu phản hồi.
    private val editLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                getStudentFromIntent(result.data, EXTRA_UPDATED_STUDENT)?.let { updated ->
                    student = updated
                    bindData(student)
                    toast("Đã lưu thông tin hồ sơ!")
                }
            }
        }

    // 2) Launcher chọn ảnh từ Gallery / Photo Picker.
    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                binding.imgAvatar.setImageURI(it)
                toast("Đã đổi ảnh đại diện!")
            }
        }

    // 3) Launcher xin quyền Camera tại runtime.
    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                toast("Đã cấp quyền Camera!")
            } else {
                toast("Bạn đã từ chối quyền Camera.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "MainActivity -> onCreate")

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bindData(student)

        binding.btnEditProfile.setOnClickListener {
            val intent = Intent(this, EditProfileActivity::class.java).apply {
                putExtra(EXTRA_STUDENT, student)
            }
            editLauncher.launch(intent)
        }

        binding.btnChangeAvatar.setOnClickListener {
            galleryLauncher.launch("image/*")
        }

        binding.btnCallHotline.setOnClickListener {
            openDialer(student.phone)
        }

        binding.btnRequestCamera.setOnClickListener {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }

        // Bài mở rộng: mở vị trí trường bằng bản đồ.
        binding.btnOpenMap.setOnClickListener {
            openSchoolMap()
        }
    }

    private fun bindData(s: Student) {
        binding.tvName.text = s.name
        binding.tvDetails.text = buildString {
            append("MSSV: ${s.id}\n")
            append("Lớp: ${s.className}\n")
            append("Email: ${s.email}\n")
            append("SĐT: ${s.phone}")
        }

        binding.tvGpaBadge.text =
            "GPA: ${"%.2f".format(s.gpa)} • ${gpaRank(s.gpa)}"
    }

    private fun gpaRank(gpa: Double): String = when {
        gpa >= 3.6 -> "Xuất sắc"
        gpa >= 3.2 -> "Giỏi"
        gpa >= 2.5 -> "Khá"
        gpa >= 2.0 -> "Trung bình"
        else -> "Cần cố gắng"
    }

    private fun openDialer(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$phoneNumber")
        }
        safeStartIntent(intent, "Không tìm thấy ứng dụng gọi điện.")
    }

    private fun openSchoolMap() {
        val geoUri = Uri.parse(
            "geo:16.0768,108.2141?q=Đại+học+Sư+phạm+Kỹ+thuật+Đà+Nẵng"
        )
        val intent = Intent(Intent.ACTION_VIEW, geoUri)
        safeStartIntent(intent, "Không tìm thấy ứng dụng bản đồ.")
    }

    private fun safeStartIntent(intent: Intent, errorMessage: String) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast(errorMessage)
        }
    }

    private fun getStudentFromIntent(intent: Intent?, key: String): Student? {
        intent ?: return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra(key, Student::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra(key) as? Student
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    // 7 callback vòng đời Activity để quan sát trong Logcat.
    override fun onStart() {
        super.onStart()
        Log.d(TAG, "MainActivity -> onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "MainActivity -> onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "MainActivity -> onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "MainActivity -> onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG, "MainActivity -> onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "MainActivity -> onDestroy")
    }
}
