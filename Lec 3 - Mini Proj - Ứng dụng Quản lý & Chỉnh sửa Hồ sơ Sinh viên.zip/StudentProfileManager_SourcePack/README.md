# Lec 3 - Mini Project - Student Profile Manager

Ứng dụng Android 2 màn hình theo Lecture 3:
- MainActivity: hiển thị hồ sơ sinh viên + avatar.
- EditProfileActivity: sửa Họ tên, Lớp, GPA và trả dữ liệu về MainActivity.
- Activity Result API:
  - StartActivityForResult
  - GetContent
  - RequestPermission
- Implicit Intent: mở bàn phím gọi điện.
- 7 callback vòng đời ghi Logcat với tag `TAG_LIFECYCLE`.
- Bài mở rộng: mở bản đồ vị trí UTE bằng Geo URI.

## BẮT BUỘC thay thông tin cá nhân

Mở:
`app/src/main/java/com/example/studentprofilemanager/MainActivity.kt`

Tìm khối:

```kotlin
private var student = Student(
    id = "THAY_MSSV_CUA_BAN",
    name = "THAY_HO_TEN_CUA_BAN",
    className = "THAY_LOP_CUA_BAN",
    email = "THAY_EMAIL_CUA_BAN",
    phone = "0905123456",
    gpa = 3.80
)
```

Thay bằng thông tin thật của bạn trước khi quay clip và push Git.

## Cách dùng nhanh nhất

1. Android Studio -> New Project -> **Empty Views Activity**, Kotlin.
2. Đóng project mới.
3. Chép các file trong SourcePack này vào project mới.
4. GIỮ LẠI `gradlew`, `gradlew.bat`, `gradle/wrapper/` do Android Studio tạo.
5. Mở lại project -> Sync Gradle -> Run.

Nếu Android Studio của bạn tạo plugin/Gradle mới hơn, có thể giữ `settings.gradle.kts`,
`build.gradle.kts`, `gradle.properties` của project mới và chỉ thay:
- thư mục `app/src/main`
- phần `buildFeatures { viewBinding = true }`
- dependencies CardView/Material trong `app/build.gradle.kts`.

## Kiểm thử trước khi quay clip

- TC-01: bấm Chỉnh sửa -> thấy đúng Tên/Lớp/GPA cũ.
- TC-02: đổi GPA thành 3.95 -> Lưu -> Main hiển thị 3.95 và "Xuất sắc".
- TC-03: vào sửa rồi bấm Hủy -> dữ liệu Main không đổi.
- TC-04: Đổi Avatar -> chọn ảnh -> ảnh hiển thị.
- TC-05: Kiểm tra quyền Camera -> hiện popup và Toast.
- Thử nút gọi điện.
- Thử nút bản đồ (bài mở rộng).
- Logcat lọc: `tag:TAG_LIFECYCLE`.

## Kịch bản quay clip gợi ý

1. Mở app, quay màn hình hồ sơ có thông tin cá nhân.
2. Bấm Chỉnh sửa, cho thấy dữ liệu cũ đã điền sẵn.
3. Đổi GPA thành 3.95, bấm Lưu và Phản Hồi.
4. Cho thấy MainActivity cập nhật GPA 3.95 - Xuất sắc.
5. Vào sửa lần nữa rồi bấm Hủy, chứng minh dữ liệu không đổi.
6. Bấm Đổi Avatar và chọn một ảnh.
7. Bấm Gọi số điện thoại.
8. Quay lại app, bấm Kiểm tra quyền Camera.
9. Bấm Mở bản đồ trường UTE.
10. Có thể quay nhanh Logcat với filter `tag:TAG_LIFECYCLE`.

## Git

```powershell
git add .
git commit -m "Lec 3 Mini Project Student Profile Manager"
git push origin main
```
